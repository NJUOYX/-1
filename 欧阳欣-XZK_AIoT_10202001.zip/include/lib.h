#ifndef __LIB_H__
#define __LIB_H__
int clockin_machine_start(int s2m, int workhours);
#endif//__LIB_H__